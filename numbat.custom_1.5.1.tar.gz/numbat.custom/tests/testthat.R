library(numbat.custom)

testthat::test_check("numbat.custom")
